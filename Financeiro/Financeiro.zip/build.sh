#!/bin/bash

zip -r "Financeiro.zip" * -x "Financeiro.zip"